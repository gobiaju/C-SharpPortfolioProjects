﻿namespace MinotaurLabyrinth
{
	interface IInteractable
	{
		void Interact(Character player);
	}
}