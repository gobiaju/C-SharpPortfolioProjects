﻿namespace MinotaurLabyrinth
{
    abstract class Merchant : IInteractable
    {
        readonly protected Inventory _inventory = new(1000f);
        readonly protected float _ratio = 0.5f;
        protected Type _merchantType;
        public void Interact(Character player)
        {
            GetCommand(player);
        }
        private void GetCommand(Character player)
        {
            while (true)
            {
                Console.Clear();
                Console.WriteLine("Welcome to my shop.\n");
                GoldDisplay(player);
                Console.WriteLine("\nBuy");
                Console.WriteLine("Sell");
                Console.WriteLine("Quit");
                Console.WriteLine("\nWhat would you like to do?");
                string input = Console.ReadLine().ToLower();
                switch (input)
                {
                    case "buy":
                        Buy(player);
                        break;
                    case "sell":
                        Sell(player);
                        break;
                    case "quit":
                        return;
                }
            }
        }

        /// <summary>
        /// Allows the player to buy items from the merchant. 
        /// Items must be of the appropriate item class for the merchant to consider them.
        /// </summary>
        /// <param name="player">Player to interact with</param>
        private void Buy(Character player)
        {
            Console.Clear();
            while (true)
            {
                GoldDisplay(player);
                Console.WriteLine("\nHere is a list of my items for sale.\n");
                this._inventory.DisplayItemsValue(_merchantType);
                Console.WriteLine("\nEnter the item name or its number to purchase it. Type quit to return to the previous menu.");
                string input = Console.ReadLine().ToLower().Replace(" ","");
                if (input == "quit") return;

                InventoryItem? item = this._inventory.ContainsItem(input);
                if (item != null)
                {
                    if (player.GetInventory().RemoveGold(item.Value))
                    {
                        if (player.GetInventory().AddItem(item))
                        {
                            this._inventory.Remove(item.IType);
                            this._inventory.AddGold(item.Value);
                            Console.Clear();
                            ConsoleHelper.WriteLine($"{item.Name} purchased!", ConsoleColor.Green);
                        }
                        else
                        {
                            player.GetInventory().AddGold(item.Value);
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Allows the player to sell items to the merchant at a discounted price. 
        /// Items must be of the appropriate item class for the merchant to consider them.
        /// </summary>
        /// <param name="ratio">The ratio used by the merchant class when buying items from the player.</param>
        /// <param name="player">Player to interact with</param>
        private void Sell(Character player)
        {
            Console.Clear();
            while (true)
            {
                GoldDisplay(player);
                Console.WriteLine("\nHere is a list of your items I'm willing to buy at a \"reasonable\" price.\n");
                player.GetInventory().DisplayItemsValue(_merchantType, _ratio);
                Console.WriteLine("\nEnter the item name or its number to sell it. Type quit to return to the previous menu.");
                string input = Console.ReadLine().ToLower().Replace(" ", "");
                if (input == "quit") return;

                InventoryItem? item = player.GetInventory().ContainsItem(input);
                if (item != null)
                {
                    Console.WriteLine();
                    if (this._merchantType == item.GetType().BaseType) // Ensures the item type is one the merchant is interested in.
                    {
                        if (this._inventory.RemoveGold(item.Value * _ratio))
                        {
                            if (this._inventory.AddItem(item))
                            {
                               
                                player.GetInventory().Remove(item.IType);
                                player.GetInventory().AddGold(item.Value * _ratio);
                                Console.Clear();
                                ConsoleHelper.WriteLine($"{item.Name} sold!", ConsoleColor.Green);
                                //player.Inventory.SortByType();
                            }
                            else
                            {
                                this._inventory.AddGold(item.Value * _ratio); // Adding the item has failed, gold must be refunded to the player.
                            }
                        }
                    }
                    else 
                    {
                        Console.Clear();
                        ConsoleHelper.WriteLine($"I don't want to buy that item.", ConsoleColor.Magenta);
                    }
                }
            }
        }

        private void GoldDisplay(Character player)
        {
            Console.Write("Merchant Gold: ");
            ConsoleHelper.Write($"{this._inventory.Gold} ", ConsoleColor.Yellow);
            Console.Write("Player Gold: ");
            ConsoleHelper.WriteLine($"{player.GetInventory().Gold}", ConsoleColor.Yellow);
        }
    }

    class PotionMerchant : Merchant
    {
        public PotionMerchant()
        {
            _merchantType = typeof(Consumable);
            for (int i = 0; i < 5; i++)
            {
                HealingPotion pot = new();
                _inventory.AddItem(pot);
            }
        }
    }

    class ArmorMerchant : Merchant
    {
        public ArmorMerchant()
        {
            _merchantType = typeof(Armor);
            Shield shield = new();
            _inventory.AddItem(shield);
        }
    }

    class WeaponMerchant : Merchant
    {
        public WeaponMerchant()
        {
            _merchantType = typeof(Weapon);
            Sword sword = new();
            _inventory.AddItem(sword);
        }
    }

    public static class ConsoleHelper
    {
        // Changes to the specified color and then displays the text on its own line.
        public static void WriteLine(string text, ConsoleColor color)
        {
            Console.ForegroundColor = color;
            Console.WriteLine(text);
            Console.ResetColor();
        }

        // Changes to the specified color and then displays the text without moving to the next line.
        public static void Write(string text, ConsoleColor color)
        {
            Console.ForegroundColor = color;
            Console.Write(text);
            Console.ResetColor();
        }
    }
}