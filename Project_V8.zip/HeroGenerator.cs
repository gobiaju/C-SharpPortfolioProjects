﻿namespace MinotaurLabyrinth
{
    class HeroGenerator
    {
        /// <summary>
        /// This method 
        /// </summary>
        /// <returns></returns>
        public static Character GenerateHero()
        {
            Console.WriteLine("Welcome to the hero generator!\n");

            string name = GetHeroName();
            Console.WriteLine($"Thank you {name}. Select the hero class you'd like to create.\n");

            Character hero = GetHeroClass(name);
            CustomizeHero(hero);
            return hero;
        }

        /// <summary>
        /// Prompts the user to get enter a name for the hero
        /// </summary>
        /// <returns>A string representing the hero name</returns>
        private static string GetHeroName()
        {
            string input;
            while (true)
            {
                Console.WriteLine("Please enter the name for the hero. The maximum length is 12 characters.");
                input = Console.ReadLine().Trim();
                if (input.Length > 12)
                {
                    Console.Clear();
                    Console.WriteLine("Sorry, that name is too long.\n");
                }
                else if (input.Length == 0)
                {
                    Console.Clear();
                    Console.WriteLine("You haven't entered a name.\n");
                }
                else break;
            }
            return input;
        }

        /// <summary>
        /// Prompts the user to select a hero class
        /// </summary>
        /// <param name="name">Name used when creating the Character subclass</param>
        /// <returns>A new Character object</returns>
        private static Character GetHeroClass(string name)
        {
            while (true)
            {
                Console.WriteLine("Fighter");
                Console.WriteLine("Rogue");
                Console.WriteLine("Mage");

                string input = Console.ReadLine().ToLower();

                switch (input)
                {
                    case "fighter":
                        return new Fighter(name);
                    case "rogue":
                        return new Rogue(name);
                    case "mage":
                        return new Mage(name);
                    default:
                        Console.Clear();
                        Console.WriteLine($"Sorry {name}, unable to find that class, please try again.\n");
                        break;
                }
            }
        }
        /// <summary>
        /// Allows the user to customize the new hero Character
        /// </summary>
        /// <param name="hero">The character to be customized</param>
        /// <returns>The character after its been customized</returns>
        private static Character CustomizeHero(Character hero)
        {
            int pts = 5;

            while (pts > 0)
            {
                Tuple<Attribs, bool> selectedAtr = SelectAttribute(hero, pts);
                if (selectedAtr.Item2 == true) break; // User has entered 'q' instead of selecting an attribute signaling an end to this method.
                Attribs attribute = selectedAtr.Item1;
                Tuple<Character, int> data = ChangeAttribute(hero, attribute, pts);
                hero = data.Item1;
                pts = data.Item2;
            }
            Console.WriteLine("");
            return hero;
        }

        /// <summary>
        /// Lists the number of customization points remaining and all the attributes for a character, prompting the user to select one.
        /// </summary>
        /// <param name="hero">Character to work with</param>
        /// <param name="pts">The points remaining</param>
        /// <returns>The selected attribute and a bool which represents the users choice to abort the selection process.</returns>
        private static Tuple<Attribs, bool> SelectAttribute(Character hero, int pts) // if return bool is true, quit
        {
            while (true)
            {
                Console.WriteLine("Current attributes: \n");
                foreach (KeyValuePair<Attribs, int> kvp in hero.GetAttributes())
                {
                    Console.WriteLine($"{kvp.Key}: {kvp.Value}");
                }
                Console.WriteLine($"\nYou have {pts} points remaining.\n");
                Console.WriteLine("Select an attribute to modify or type 'q' to quit.");
                string input = Console.ReadLine().ToLower();
                if (input == "q") return Tuple.Create(Attribs.Strength, true); // Could this be better?
                if (Enum.TryParse(input, true, out Attribs attribute))
                {
                    if (hero.GetAttributes().ContainsKey(attribute)) return Tuple.Create(attribute, false); // Same...
                    else ConsoleHelper.WriteLine($"{attribute} was not found is the hero attributes list.\n", ConsoleColor.Red);
                }
                else 
                {
                    Console.Clear();
                    ConsoleHelper.WriteLine($"{input} is not a valid attribute type.\n", ConsoleColor.Red);
                }
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="hero"></param>
        /// <param name="attribute"></param>
        /// <param name="pts"></param>
        /// <returns></returns>
        private static Tuple<Character, int> ChangeAttribute(Character hero, Attribs attribute, int pts)
        {
            Console.Clear();
            while (true)
            {
                Console.WriteLine($"\n{attribute} is currently at {hero.GetAttributes()[attribute]}\n");
                Console.WriteLine($"You have {pts} remaining; enter a value between -{hero.GetAttributes()[attribute] - 1} and {pts} or type 'q' to return to the previous menu.");

                string input = Console.ReadLine();
                if (input == "q") return Tuple.Create(hero, pts);

                if (Int32.TryParse(input, out int adjNum))
                {
                    if (adjNum <= pts && adjNum >= -hero.GetAttributes()[attribute] - 1) // Add proper error message, this works but doesn't inform user of the problem!
                    {
                        hero.GetAttributes()[attribute] += adjNum; // explain this!
                        pts -= adjNum;
                        Console.Clear();
                        Console.WriteLine($"Changed {attribute} by {adjNum}. {attribute} is now {hero.GetAttributes()[attribute]}.\n");
                        return Tuple.Create(hero, pts);
                    }
                    else
                    {
                        Console.Clear();
                        ConsoleHelper.WriteLine($"{adjNum} is outside of valid range, please try again.", ConsoleColor.Red);
                    }
                }
                else
                {
                    Console.Clear();
                    ConsoleHelper.WriteLine("Not a valid number!", ConsoleColor.Red);
                }
            }
        }
    }
}
