﻿using System.Text.Json.Serialization;

namespace MinotaurLabyrinth
{

	abstract class Character
	{
		protected const int MaxHealth = 100;
		protected readonly int defaultStat = 0;
		protected int _health = MaxHealth;

		protected string _name;
		protected Dictionary<Attribs, int> _attributes = new(); 
		protected Inventory _inventory = new();

		protected CharacterSheet _sheet = new();

		protected virtual CharacterClass PlayerClass { get; }

		public Character()
		{
			_name = "";
			_attributes.Add(Attribs.Strength, defaultStat);
			_attributes.Add(Attribs.Dexterity, defaultStat);
			_attributes.Add(Attribs.Constitution, defaultStat);
			_attributes.Add(Attribs.Wisdom, defaultStat);
			_attributes.Add(Attribs.Intelligence, defaultStat);
			_attributes.Add(Attribs.Charisma, defaultStat);
		}

		public Character(CharacterSheet sheet)
        {
			_name = sheet.Name;
			_attributes = sheet.Attributes;
			_inventory = sheet.Inventory;
			PlayerClass = sheet.PlayerClass;
			_sheet = sheet;
        }

		public struct CharacterSheet
		{
			public CharacterSheet(string name, Dictionary<Attribs, int> attributes, Inventory inventory, CharacterClass playerClass)
			{
				Name = name;
				Attributes = attributes;
				Inventory = inventory;
				PlayerClass = playerClass;
			}
			public string Name { get; set; }
			public Dictionary<Attribs, int> Attributes { get; set; }
			public Inventory Inventory { get; set; }
			public CharacterClass PlayerClass { get; set; }
		}

		public int Health
        {
			get { return _health; }
            set 
			{
				if (value < 0) _health = 0;
				else if (value > MaxHealth) _health = MaxHealth;
				else _health = value;
			}
        }

		// Forwarding methods
		public void AddItem(InventoryItem item) => _inventory.AddItem(item);
		public void Consume(Consumable item) => item.Consume(this);

		// New methods
		public Inventory GetInventory() => _inventory;
		public CharacterSheet GetCharacterSheet() => _sheet;
		public Dictionary<Attribs, int> GetAttributes() => _attributes;

		public int? GetAtr(Attribs stat)
		{
			foreach (KeyValuePair<Attribs, int> kvp in _attributes)
			{
				if (kvp.Key == stat)
				{
					return kvp.Value;
				}
			}
			return null;
		}

		public void AdjAtr(Attribs stat, int amount)
		{
			if (_attributes.ContainsKey(stat))
			{
				if (_attributes[stat] + amount > 0)
				{
					_attributes[stat] += amount;
				}
				else
				{
					Console.WriteLine("THROW ERROR, CANNOT SET ATTRIBUTE BELOW 1"); // implement this properly!
				}

			}
			else
			{
				Console.WriteLine("THROW ERROR, ATTRIBUTE NOT FOUND!"); // implement this properly!
			}
		}

		public virtual void Attack(Character character)
        {
			
        }

		public virtual void Defend(Character character)
        {

        }

		public virtual void Special(Character character)
        {

        }

		/**************************************************************************************************
             * You do not need to alter anything below here but you are free to do
             * For example - while under the effects of a potion of invulnerability, the player cannot die
         *************************************************************************************************/

		// Indicates whether the player is alive or not.
		public bool IsAlive
		{
			get => _health > 0;
		}

		// Represents the distance the player can sense danger.
		// Diagonal adjacent squares have a range of 2 from the player.
		public int SenseRange { get; } = 1;


		// Creates a new player that starts at the given location.
		//public Player(Location start) => Location = start;
		// The player's current location.
		//public Location Location { get; set; }

		// Explains why a player died.
		public string? CauseOfDeath { get; private set; }

		public void Kill(string cause)
		{
			_health = 0;
			CauseOfDeath = cause;
		}
	}

	// Represents a location in the 2D game world, based on its row and column.
	public record Location(int Row, int Column);
	enum Attribs { Strength, Dexterity, Constitution, Wisdom, Intelligence, Charisma }

}

