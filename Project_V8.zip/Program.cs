﻿using System;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace MinotaurLabyrinth
{
    class Program
    {
        
        static void Main(string[] args)
        {
            
            PotionMerchant potMerch = new();
            ArmorMerchant armorMerch = new();
            WeaponMerchant weaponMerchant = new();

            Map map = new();
            Sword sword125 = new();
            HealingPotion pot = new();

            //Mage hero2 = new("Tester");
            //hero2.AddItem(map);
            //Console.WriteLine(hero2.Inventory);

            //Character testplayer = HeroGenerator.GenerateHero();
            //testplayer.GetInventory().AddItem(sword125);
            //HeroIO.SaveHero(testplayer);

            Character newtest = HeroIO.LoadHero();
            Console.WriteLine($"You loaded {newtest.GetCharacterSheet().Name}!");




            //testplayer.Inventory.AddItem(pot);
            //Console.WriteLine("testplayer info:");

            //Tester(player1, potMerch, map, sword, pot);
            //player1.DisplayItemsValue(MerchType.Consumable);

            //potMerch.Interact(player1);
            //Console.Clear();
            //armorMerch.Interact(player1);
            //Console.Clear();
            //weaponMerchant.Interact(player1);
        }
        public static void Tester(Character player, Merchant merchant, Map map, Sword sword12, HealingPotion pot)
        {
            Console.WriteLine("Initial Test");
            Console.WriteLine($"Contains Map: {player.GetInventory().ContainsMap()}");
            Console.WriteLine($"Contains Sword: {player.GetInventory().ContainsSword()}");
            Console.WriteLine($"Player Health: {player.Health}");

            player.Health -= 15;
            Console.WriteLine($"\nDamaged Health: {player.Health}");

            player.GetInventory().AddItem(map);
            player.GetInventory().AddItem(sword12);
            player.GetInventory().Remove(ItemType.Sword);

            Console.WriteLine("\nItems:");
            player.GetInventory().DisplayItems();

            player.Consume(pot);

            Console.WriteLine("\nTest");
            Console.WriteLine($"Contains Map: {player.GetInventory().ContainsMap()}");
            Console.WriteLine($"Contains Sword: {player.GetInventory().ContainsSword()}");
            Console.WriteLine($"Player Health: {player.Health}");

            Console.WriteLine("\nRemoving Map...");
            player.GetInventory().Remove(map.IType);


            Console.WriteLine("\nNew Test");
            Console.WriteLine("\nItems:");
            player.GetInventory().DisplayItems();
            Console.WriteLine($"Contains Map: {player.GetInventory().ContainsMap()}");
        }
    }

}

