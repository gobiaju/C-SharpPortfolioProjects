﻿namespace MinotaurLabyrinth
{
    class Inventory
    {
        public List<InventoryItem> _items { get; set; } = new();
        private float _gold;
        private readonly int _maxCount;
        private int _currentCount;

        public float Gold => _gold;

        
        public Inventory(int maxCount, float gold)
        {
            _maxCount = maxCount;
            _gold = gold;
        }
        public Inventory(float gold) : this(10, gold) { }
        public Inventory() : this(10, 50) { }
        public void SortByType()
        {
            _items = _items.OrderBy(item => item.GetType().Name).ToList();
        }

        public void SortByValue()
        {
            _items = _items.OrderBy(item => item.Value).ToList();
        }
        public bool ContainsSword() => (_items.OfType<Sword>().Any());
        public bool ContainsMap() => (_items.OfType<Map>().Any());
        public void AddGold(float amount) => _gold += amount;

        public bool RemoveGold(float amount)
        {
            if (_gold - amount >= 0)
            {
                _gold -= amount;
                return true;
            }
            else
            {
                Console.Clear();
                ConsoleHelper.WriteLine($"Not enough gold!", ConsoleColor.Red);
            }
            return false;
        }

        public void DisplayItems()
        {
            foreach (var item in _items)
            {
                Console.WriteLine(item.Name);
            }
        }

        /// <summary>
        /// Used to display all items in a list along with their index number.
        /// Will be displayed in red if the item doesn't match the merchant class.
        /// </summary>
        /// <param name="mtype">Represents the merchant type</param>
        /// <param name="ratio">Used to adjust the trade value when dealing with merchants</param>
        public void DisplayItemsValue(Type mtype, float ratio = 1f)
        {
            for (int i = 0; i < _items.Count; i++)
            {
                if (_items[i].GetType().BaseType == mtype)
                {
                    Console.Write($"No. {i}, {_items[i].Name}, Value: ");
                    ConsoleHelper.WriteLine($"{_items[i].Value * ratio}", ConsoleColor.Cyan);
                }
                else
                {
                    ConsoleHelper.WriteLine($"No. {i}, {_items[i].Name}, Value: N/A", ConsoleColor.Red);
                }
            }
        }

        /// <summary>
        /// Adds items to an inventory, must pass the AddItemCheck requirements first.
        /// </summary>
        /// <param name="item">Item to be added</param>
        /// <returns>Returns true when the item has been successfully added, otherwise returns false</returns>
        public bool AddItem(InventoryItem item)
        {
            int quantity = 1; // get rid of the quantity piece in this code!
            if (AddItemCheck(item))
            {
                int index = FindItemIndex(item);
                if (index == -1) // -1 means the no items of this type exist in the inventory
                {
                    _items.Add(item);
                    _items[^1].IncreaseQuantity(quantity - 1);
                }
                else
                {
                    _items[index].IncreaseQuantity(quantity);
                }
                this.SortByType();
                _currentCount++;
                return true;
            }
            return false;
        }

        public void Add(InventoryItem item, int quantity = 1)
        {
            int index = FindItemIndex(item);
            if (index == -1) // -1 means the no items of this type exist in the inventory
            {
                _items.Add(item);
                _items[^1].IncreaseQuantity(quantity - 1);
            }
            else
            {
                _items[index].IncreaseQuantity(quantity);
            }
        }

        private int FindItemIndex(ItemType target)
        {
            for (int i = 0; i < _items.Count; ++i)
            {
                if (_items[i].IType == target)
                {
                    return i;
                }
            }
            return -1;
        }

        private int FindItemIndex(InventoryItem target)
        {
            for (int i = 0; i < _items.Count; ++i)
            {
                if (_items[i].Equals(target))
                {
                    return i;
                }
            }
            return -1;
        }

        /// <summary>
        /// Checks the inventory to ensure there's sufficient room, weight and volume capacity.
        /// Used before adding an item.
        /// </summary>
        /// <param name="item">Item that's being checked</param>
        /// <returns>Returns true if the item will be added, false if any problems arise.</returns>
        private bool AddItemCheck(InventoryItem item)
        {
            if (_currentCount >= _maxCount)
            {
                Console.Clear();
                ConsoleHelper.WriteLine($"Unable to add {item.Name}; inventory is full!", ConsoleColor.Red);
                return false;
            }
            return true;
        }

        /// <summary>
        /// Used to remove an item from the inventory using its index
        /// </summary>
        /// <param name="index">Represents an item' list index</param>
        public void Remove(int index)
        {
            _currentCount--;
            _items.RemoveAt(index);
            this.SortByType();
        } 
        /// <summary>
        /// Searches the list for a matching type, then passes the item' list index to the primary Remove method
        /// </summary>
        /// <param name="type">Represents the item' type</param>
        public void Remove(ItemType type)
        {
            for (int i = 0; i < _items.Count; i++)
            {
                if (_items[i].IType == type)
                {
                    Remove(i);
                    return;
                }
            }
        }

        /// <summary>
        /// Parses the string entered by the player; numbers will be matched to the list index while words will be searched against the possible ItemTypes.
        /// </summary>
        /// <param name="input">The string to be parsed</param>
        /// <returns>Returns the item object from the list if found, otherwise returns null.</returns>
        public InventoryItem? ContainsItem(string input)
        {
            if (int.TryParse(input, out int n))
            {
                if (n >= _items.Count || n < 0)
                {
                    Console.Clear();
                    ConsoleHelper.WriteLine($"Number {input} is outside of the valid range, please try again.", ConsoleColor.Red);
                    return null;
                }
                return _items[n];
            }
            if(Enum.TryParse(input, true, out ItemType type))
            {
                foreach (InventoryItem item in _items)
                {
                    if (item.IType == type) return item;
                }
            }
            else
            {
                Console.Clear();
                ConsoleHelper.WriteLine($"Unable to find {input} in list, please try again.", ConsoleColor.Red);
            }
            
            return null;
        }

        public override string ToString()
        {
            string ret = $"There are currently {_items.Count} item(s) in the inventory.";
            ret += "\nItems in the inventory include:\n";
            foreach (InventoryItem item in _items)
            {
                ret += $"{item.Name}\n";
            }
            return ret;
        }


    }
}
