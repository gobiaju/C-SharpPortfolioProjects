﻿namespace MinotaurLabyrinth
{
    class Fighter : Character
    {
        protected override CharacterClass PlayerClass { get; } = CharacterClass.Fighter;
        public Fighter(string name) : base() 
        {
            _name = name;
            AdjAtr(Attribs.Strength, 18);
            AdjAtr(Attribs.Dexterity, 12);
            AdjAtr(Attribs.Constitution, 16);
            AdjAtr(Attribs.Wisdom, 10);
            AdjAtr(Attribs.Intelligence, 10);
            AdjAtr(Attribs.Charisma, 10);
            _sheet = new(name, base._attributes, base._inventory, PlayerClass);
        }

        public Fighter(CharacterSheet sheet) : base(sheet) { }
        public override void Special(Character character)
        {
            string title = "Grapple";
            
        }
        public void Cheatdeath()
        {
            string title = "Grapple";
            
        }
    }

    class Rogue : Character
    {
        protected override CharacterClass PlayerClass { get; } = CharacterClass.Rogue;
        public Rogue(string name) : base() 
        {
            _name = name;
            AdjAtr(Attribs.Strength, 12);
            AdjAtr(Attribs.Dexterity, 18);
            AdjAtr(Attribs.Constitution, 12);
            AdjAtr(Attribs.Wisdom, 10);
            AdjAtr(Attribs.Intelligence, 10);
            AdjAtr(Attribs.Charisma, 14);
            _sheet = new(name, base._attributes, base._inventory, PlayerClass);
        }
        public Rogue(CharacterSheet sheet) : base(sheet) { }
        public override void Special(Character character)
        {
            string title = "Steal";
        }
 
        public void Steal(Character character)
        {
            //Random rng = new Random();
            //int test = rng.Next(1, 2);
            float amount = 500; // rng 1 - 20 * dex
            if (amount < character.GetInventory().Gold)
            {
                GetInventory().AddGold(amount);
                character.GetInventory().RemoveGold(amount);
            }

            else
            {
                GetInventory().AddGold(character.GetInventory().Gold);
                character.GetInventory().RemoveGold(character.GetInventory().Gold);
            }
        }
    }

    class Mage : Character
    {
        protected override CharacterClass PlayerClass { get; } = CharacterClass.Mage;
        protected string Name { get; } = "aha!";
        //public CharacterSheet sheet = new();
        public Mage(string name) : base() 
        {
            _name = name;
            AdjAtr(Attribs.Strength, 10);
            AdjAtr(Attribs.Dexterity, 12);
            AdjAtr(Attribs.Constitution, 10);
            AdjAtr(Attribs.Wisdom, 16);
            AdjAtr(Attribs.Intelligence, 18);
            AdjAtr(Attribs.Charisma, 12);
            _sheet = new(name, _attributes, _inventory, PlayerClass);
        }
        public Mage(CharacterSheet sheet) : base(sheet) { }
        public override void Special(Character character)
        {
            string title = "Spell";
        }
    }

    enum CharacterClass { Fighter, Rogue, Mage }

}
