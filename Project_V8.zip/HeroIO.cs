﻿using System.Text.Json;
//using Newtonsoft.Json;

namespace MinotaurLabyrinth
{

    class HeroIO
    {
        const string OutputPrefix = "hero_"; // Filename prefix added to all hero files when saving

        /// <summary>
        /// Saves a character to a .json format file. If the file already exists, user will be prompted to overwrite it.
        /// </summary>
        /// <param name="hero">Character object to be saved.</param>
        public static void SaveHero(Character hero)
        {
            //hero.GetCharacterSheet().Inventory = hero.GetInventory();
            var opt = new JsonSerializerOptions() { WriteIndented = true };
            string jsonString = JsonSerializer.Serialize(hero.GetCharacterSheet(), opt);
            string filename = OutputPrefix + hero.GetCharacterSheet().Name + ".json";

            if (filename != null)
            {
                if (File.Exists(filename))
                {
                    Console.Clear();
                    ConsoleHelper.WriteLine($"A hero file named {filename} already exists. Would you like to overwrite? (y/n)", ConsoleColor.Cyan);
                    string input = Console.ReadLine().ToLower();
                    if (input == "y") File.WriteAllText($"{filename}", jsonString);
                    else
                    {
                        ConsoleHelper.WriteLine($"Failed to save.", ConsoleColor.Red);
                        return;
                    }

                }
                File.WriteAllText($"{filename}", jsonString);
            }
            ConsoleHelper.WriteLine($"Saved.", ConsoleColor.Green); ;
        }

        /// <summary>
        /// Lists all hero_ files in the running directory, allowing the user to select one to load.
        /// </summary>
        /// <returns>A character object loaded from a file the user will specify</returns>
        public static Character? LoadHero()
        {
            string path = SelectHero();
            var opt = new JsonSerializerOptions() { WriteIndented = true, };
            string text = System.IO.File.ReadAllText(path);
            var data = JsonSerializer.Deserialize<Character.CharacterSheet>(text, opt);
            switch (data.PlayerClass)
            {
                case CharacterClass.Fighter:
                    Fighter fighter = new(data);
                    return fighter;
                case CharacterClass.Rogue:
                    Rogue rogue = new(data);
                    return rogue;
                case CharacterClass.Mage:
                    Mage mage = new(data);
                    return mage;
            }
            return null;
        }

        /// <summary>
        /// Lists all files in the running folder using the ProcessDirectory() method, then prompts the user to select one of the characters to load.
        /// </summary>
        /// <returns>A string containing the full path to the hero file to be loaded.</returns>
        public static string SelectHero() 
        {
            Dictionary<string, string> files = ProcessDirectory(); // Gets all hero_ files in the running directory.
            while (true)
            {
                Console.WriteLine("Enter the name of the hero you'd like to load:");
                foreach (KeyValuePair<string, string> kvp in files)
                {
                    Console.WriteLine(kvp.Value);
                }
                string input = Console.ReadLine().ToLower();
                foreach (KeyValuePair<string, string> kvp in files)
                {
                    if (kvp.Value.ToLower() == input) return kvp.Key; // Hero file matching the user input gets returned
                }
                Console.Clear();
                ConsoleHelper.WriteLine("Sorry, that is not a valid input.\n", ConsoleColor.Red);
            }
        }

        /// <summary>
        /// Gets all files in the working directory, looking for those with a _hero prefix.
        /// Strips out the path, _hero prefix and file extension for the file variable which is later used to present selectable heroes.
        /// Adds the full path and file to the files dictionary.
        /// </summary>
        /// <returns>Dictionary containing a full path to a hero_name.json file and matching name</returns>
        public static Dictionary<string, string> ProcessDirectory()
        {
            Dictionary<string, string> files = new();
            string[] fileEntries = Directory.GetFiles(AppDomain.CurrentDomain.BaseDirectory);
            foreach (string filePath in fileEntries) 
            {
                string file = filePath[(filePath.LastIndexOf('\\') + 1)..]; // Strips the path out, based on the last \ in the string
                if (file.StartsWith(OutputPrefix))
                {
                    file = file.Remove(0, 5); // Strips the hero_ prefix
                    file = file.Substring(0, file.LastIndexOf(".")); // Strips the file extension
                    files.Add(filePath, file);
                }
            }
            return files;
        }
    }
}
