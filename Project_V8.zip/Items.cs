﻿namespace MinotaurLabyrinth
{
    class InventoryItem // abstract class causing loading issue?
    {
        protected float _value;
        protected ItemType _iType;
        protected string _name;
        protected int _quantity = 1;
        protected bool _isUnique = false;

        public ItemType IType => _iType;
        public string Name => _name;
        public float Value => _value;

        public InventoryItem(string name, ItemType itype, float value)
        {
            _name = name;
            _value = value;
            _iType = itype;
        }

        public InventoryItem() { }

        //public abstract InventoryItem Clone();

        public void IncreaseQuantity(int amount = 1)
        {
            if (!_isUnique)
            {
                _quantity += amount;
            }
        }

        public bool DecreaseAmount(int amount = 1)
        {
            bool itemsLeft = false;
            if (_quantity - amount > 0)
            {
                _quantity -= amount;
                itemsLeft = true;
            }
            // Return true if _quantity > 0 after the decrease
            return itemsLeft;
        }
    }

    abstract class Armor : InventoryItem
    {
        public int ArmorClass { get; set; }

        public Armor(string name, ItemType type, float value, int armorclass) : base(name, type, value) 
        {
            ArmorClass = armorclass;
        }
    }

    abstract class Consumable : InventoryItem
    {
        public Consumable(string name, ItemType type, float value) : base(name, type, value) { }
        public abstract void Consume(Character player);
    }

    abstract class Weapon : InventoryItem
    {
        public int Damage { get; set; }
        public Weapon(string name, ItemType type, float value, int damage) : base(name, type, value) 
        {
            Damage = damage;
        }
        public Weapon() : base() { }
    }

    class Map : InventoryItem
    {
        public Map() : base("Map", ItemType.Map, 50) { }
        public static InventoryItem Clone() // Used to be public override
        {
            return new Map();
        }
    }

    class Shield : Armor
    {
        public Shield() : base("Shield", ItemType.Shield, 100f, 5) { }
        public static InventoryItem Clone()
        {
            return new Shield();
        }
    }

    class Sword : Weapon
    {
        public Sword(int damage) : base("Sword", ItemType.Sword, 150f, damage) { }
        public Sword() : base("Sword", ItemType.Sword, 150f, 10) { }
        public static InventoryItem Clone()
        {
            return new Sword();
        }
    }

    class HealingPotion : Consumable
    {
        private const int _healAmount = 20;

        public HealingPotion() : base("Healing Potion", ItemType.HealingPotion, 25f) { }
        public override void Consume(Character player)
        {
            player.Health += _healAmount;
        }
        public static InventoryItem Clone()
        {
            return new HealingPotion();
        }
    }
}
enum ItemType { Miscellaneous, Sword, AncientSword, Shield, HealingPotion, Map }